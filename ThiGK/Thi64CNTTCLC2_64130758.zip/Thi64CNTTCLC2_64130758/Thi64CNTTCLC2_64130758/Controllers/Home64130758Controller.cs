﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Thi64CNTTCLC2_64130758.Controllers
{
    public class Home64130758Controller : Controller
    {
        // GET: Home64130758
        public ActionResult Index()
        {
            return View();
        }
    }
}